# NovusHaus_16-09-23
Learn how to create a stunning and responsive E-Commerce landing page from scratch using HTML, CSS, and JavaScript!
